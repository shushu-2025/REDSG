function [qx] = rq(x,r)
M=length(x);
L=2^r-1;
nor=sqrt(x'*x);
if nor==0
    qx=x;
else
    nor_x=abs(x)/nor;
    the=1/L;
    
    for m=1:M
        j_xi=floor(nor_x(m)/the);
        pr=(nor_x(m)-j_xi*the)/the;
        %     bonvli=randsrc(1,1,[0 1;1-pr pr]);
        
        j_xi_tr=randsrc(1,1,[j_xi j_xi+1;1-pr pr]);
        qx(m,1)=nor*sign(x(m))*j_xi_tr*the;
    end
end
