function [qx,rx] = PANQ(x,omiga,eta,L)
cons=omiga+sqrt(1+omiga^2);
r_k=zeros(L,1);
for ell=1:L
    m=floor(sign(x(ell))*log(1+omiga*abs(x(ell))/eta)/(2*log(cons)));
    y_m=sign(m)*eta*((cons)^(2*abs(m))-1)/omiga;
    y_mn=sign(m+1)*eta*((cons)^(2*abs(m+1))-1)/omiga;
    pr=(y_mn-x(ell))/(y_mn-y_m);
    if pr>=1
        qx(ell,1)=y_m;
    elseif pr<=0
        qx(ell,1)=y_mn;
    else
        qx(ell,1)=randsrc(1,1,[y_m y_mn;pr 1-pr]);
    end
    r_k(ell)=log2(3)*(1+ceil(log2(abs(m)+1)));
end
rx=sum(r_k);
end