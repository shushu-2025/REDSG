clc;        % clear command window
clear all;  % clear all variables
%This program tests the channel noise accumulation problem of two algorithms.
%IC-GT,TiCoPD
N = 15;             % number of agents in the network
L = 6;%64*2;             % size of wo, which is Mx1

wo = randn(L,N);wo_m= randn(L,N);%
for k=1:N
    wo_m(:,k) =1*wo(:,k)/norm(wo(:,k));  % real data (vector)
end
load wo_buton wo_m;
%load sigma_rrandn%sigma_r8_12;%sigma_rnewt;%sigma_rnew2;
%snrlow=40;snrup=60;%1e5*1*sigma_r;%
%snrlow=0;snrup=20;
% sigma_r=(0.001-0.0001)*rand(N,N)+0.0001;
% for ell=1:N
%     sigma_r(ell,ell)=0;
% end
load sigma_r sigma_r
%sigma_rlh=1+rand(1,N);
load sigma_out;
load RU;
load topology15;
load A_ba;
nei_num=sum(adjacency,2);
p=1/N*ones(N,1);%nei_num/sum(nei_num);
sum1=0;
sum2=0;c=1;
for k=1:N
    sum1=sum1+p(k,1)*RU(1,k);
    sum2=sum2+p(k,1)*RU(1,k)*c*wo_m(:,k);
    %         sum1=sum1+mu_dlms*p(k,1)*R(1,k);
    %         sum2=sum2+mu_dlms*p(k,1)*R(1,k)*wo_m(:,k);
end
wo=inv(diag(sum1))*sum2;

%%%%%%%%%%%%%%%%
mu=0.0001;
Num_trial = 20;
Num_iter  =600000;%800000;%
MSD_agent= zeros(N,Num_iter);MSD_agent_c= zeros(N,Num_iter);
MSD_agent_dd= zeros(N,Num_iter);MSD_agent_ex= zeros(N,Num_iter);
MSD_agent_exTiC= zeros(N,Num_iter);MSD_agent_ced= zeros(N,Num_iter);
sav_RCDT2= zeros(1,Num_iter);sav_TiC=zeros(1,Num_iter);
sav_RCDT3=zeros(1,Num_iter);sav_ic=zeros(1,Num_iter);sav_P2=zeros(1,Num_iter);
sav_CED=zeros(1,Num_iter);
MSD_agent_cwQ2= zeros(N,Num_iter);MSD_agent_cwQ2_IC= zeros(N,Num_iter);
omiga=0.02;eta=1/(2*L);%
% omiga=0.02;eta=1/(2*L);bit=2;
% % q_type = [12,6];
% % qc = quantizer('fixed','round','saturate',q_type);
for tt=1:Num_trial % iterating over experiments
    tt

    %%
    cphi_y=zeros(L,N);cw=0*randn(L,N);
    w_dd=cw;y_dd=zeros(L,N);pphi_dd=zeros(L,N);%zeros(L,N)
    phi_pex=0*randn(L,N);wex=cw;yex=zeros(L,N);
    yexTiC=zeros(L,N);
    wexced=cw;yexced=zeros(L,N);
    wexTiC=cw;yexjq=zeros(L,N);hatwexTiC=0*randn(L,N);
    cphi_yjq=zeros(L,N);cwjq=cw;
    sphiex=0*randn(L,N);uex=0*randn(L,N);
    w=cw;phi_yi=zeros(L,N);%w_p=zeros(L,N,(Num_iter+L));

    %%
    sum_linkav=0*randn(L,N);
    sum_link=0*randn(L,N);
    yy_dd=0*randn(L,N);
    wexp=0*randn(L,N);wexpp=0*randn(L,N);
    %%
    cphi_yQ2jq=0*randn(L,N);cphi_yQ2=0*randn(L,N);
    cphi_yQ2_IC=0*randn(L,N);
    prdettdu=zeros(L,N);
    prdettdu_IC=zeros(L,N);
    cwQ2_IC=0*randn(L,N);cwQ2=0*randn(L,N);
    isav_RCDT2= 0;isav_TiC=0;isav_CED=0;
    isav_RCDT3=0;isav_ic=0;isav_P2=0;
    %     w_la=w;
    %     w_lala=w_la;
    for i=1:(Num_iter)
        %%
        for k=1:N
            xk(:,k)=sqrt(RU(1,k)).*randn(L,1);
        end
        %%
        %dk=zeros(Num_iter+L,N);
        if i<=Num_iter+1%%;3*Num_iter/2%
            for k=1:N
                y = xk(:,k)'*c*wo_m(:,k);%wo;% filter(,1,xk(:,k));%
                %var_y=sum(y.^2)/(Num_iter+L);
                sigma_vo=1/(10^(sigma_out(k)/5/10));
                dk(k)=y+randn(1,1)*sqrt(10*sigma_vo);
            end
        else
            for k=1:N
                y = xk(:,k)'*(-c)*wo_m(:,k);%wo;% filter(,1,xk(:,k));%
                %var_y=sum(y.^2)/(Num_iter+L);
                sigma_vo=1/(10^(sigma_out(k)/5/10));
                dk(k)=y+randn(1,1)*sqrt(10*sigma_vo);
            end
        end
        eps11=0.01;%0.005;%
        eps1=eps11;%0.05;%0.2*mu^2;%20/(1*i+200);%1/(0.1*i^0.6+1);

        %%
        if i<=Num_iter+1%2.5e5%3*/2
            for k=1:N
                MSD_agent_exTiC(k,i)=MSD_agent_exTiC(k,i)+(wo-wexTiC(:,k))'*(wo-wexTiC(:,k));%TiC
                MSD_agent_cwQ2_IC(k,i)=MSD_agent_cwQ2_IC(k,i)+(wo-cwQ2_IC(:,k))'*(wo-cwQ2_IC(:,k));
            end
        else
            for k=1:N
                MSD_agent_exTiC(k,i)=MSD_agent_exTiC(k,i)+(-wo-wexTiC(:,k))'*(-wo-wexTiC(:,k));%TiC
                MSD_agent_cwQ2_IC(k,i)=MSD_agent_cwQ2_IC(k,i)+(-wo-cwQ2_IC(:,k))'*(-wo-cwQ2_IC(:,k));
            end
        end
        %%         %%  %%%%%%%%%%%%%%%%%%%%%% IC-GT
        %eps1=min([100/(100+1*i^0.8),1]);%Num_iter
        %eps1=min([100/(i),1]);%Num_iter%0.0
        %eps1=min([600*sqrt(1/(Num_iter)),1]);
        if mod(i,1)==0
            %% _IC
            for k=1:N
                cphi_ylihuaQ2_IC(:,k)=cphi_yQ2_IC(:,k);%norm(psiex(:,k)-1*wo)^2
            end
            cphi_ypQ2_IC=zeros(L,N);
            for k=1:N
                for ell=1:N
                    if A_ba(ell,k)~=0
                        cphi_ypQ2_IC(:,k)=cphi_ypQ2_IC(:,k)+A_ba(ell,k)*(cphi_ylihuaQ2_IC(:,ell)+sqrt(sigma_r(ell,k))*randn(L,1));
                    end
                end
            end
            for k=1:N
                dettdu_IC(:,k)=-(RU(1,k)*eye(L))*(c*wo_m(:,k)-cwQ2_IC(:,k));%-(1-0)*xk(:,k)*(dk(k)-xk(:,k)'*cwQ2_IC(:,k));%*
                cphi_yQ2_IC(:,k)=(1-eps1*1)*cphi_yQ2_IC(:,k)+eps1*1*cphi_ypQ2_IC(:,k)+dettdu_IC(:,k)-prdettdu_IC(:,k);
            end
            prdettdu_IC=dettdu_IC;
            for k=1:N
                cwlihuaQ2_IC(:,k)=cwQ2_IC(:,k);%norm(psiex(:,k)-1*wo)^2
            end
            cphi_wpQ2_IC=zeros(L,N);
            for k=1:N
                for ell=1:N
                    if A_ba(ell,k)~=0%
                        cphi_wpQ2_IC(:,k)=cphi_wpQ2_IC(:,k)+A_ba(ell,k)*(cwlihuaQ2_IC(:,ell)+sqrt(sigma_r(ell,k))*randn(L,1));
                    end
                end
            end
            for k=1:N
                %cwQ2_IC(:,k)= (1-eps1)*cwQ2_IC(:,k)+eps1*cphi_wpQ2_IC(:,k)-0.001*cphi_yQ2_IC(:,k);%*eps1 0.01 GT
                %cwQ2_IC(:,k)= (1-eps1)*cwQ2_IC(:,k)+eps1*cphi_wpQ2_IC(:,k)-0.1*eps1*cphi_yQ2_IC(:,k);% 0.01 GT
                cwQ2_IC(:,k)= (1-eps1)*cwQ2_IC(:,k)+eps1*cphi_wpQ2_IC(:,k)-mu*cphi_yQ2_IC(:,k);% 0.01 GT
            end
        end
        %% TiCoPD
        for k=1:N
            [rnoiseex2,rxTiC(k)]=PANQ(wexTiC(:,k)-hatwexTiC(:,k),omiga,eta,L);
            wexlihuaTiC(:,k)=rnoiseex2;%norm(psiex(:,k)-1*wo)^2
        end
        hatwexTiC=hatwexTiC+wexlihuaTiC;
        cphi_ex=zeros(L,N);
        for k=1:N
            for ell=1:N
                if A_ba(ell,k)~=0
                    cphi_ex(:,k)=cphi_ex(:,k)+(hatwexTiC(:,ell)+sqrt(sigma_r(ell,k))*randn(L,1));
                end
            end
        end
        for k=1:N
            Rsum(:,k)=cphi_ex(:,k);
            zhjgTiC(:,k)=sum(sign(A_ba(:,k)))*hatwexTiC(:,k)-Rsum(:,k);
        end
        for k=1:N
            wexTiC(:,k)=0.99*wexTiC(:,k)+(1-0.99)*hatwexTiC(:,k)-mu*(100*zhjgTiC(:,k)-xk(:,k)*(dk(k)-xk(:,k)'*wexTiC(:,k))...*(RU(1,k)*eye(L))*(10*wo_m(:,k)-wex(:,k))...%
                +yexTiC(:,k));
            yexTiC(:,k)=yexTiC(:,k)+0.005*zhjgTiC(:,k);%eps11
        end
    end
end

tt2exTiC = MSD_agent_exTiC/Num_trial; % each row contains the MSD evolution of the corresponding agent
MSD_av2exTiC = sum(tt2exTiC)/N;   % learning curve for adaptive combination matrix averaged over experiments and number of nodes
MSD_av_dbexTiC = 10*log10(MSD_av2exTiC);

tt2cwQ2_IC = MSD_agent_cwQ2_IC/Num_trial; % each row contains the MSD evolution of the corresponding agent
MSD_av2cwQ2_IC = sum(tt2cwQ2_IC)/N;   % learning curve for adaptive combination matrix averaged over experiments and number of nodes
MSD_av_dbcwQ2_IC = 10*log10(MSD_av2cwQ2_IC);

figure
hold on
iter = 1:Num_iter;

p3=plot(iter,MSD_av_dbcwQ2_IC(1,1:end),'-.x');p3.MarkerSize = 10;
p3.MarkerIndices = 1:floor(Num_iter/8):length(iter);


p5=plot(iter,MSD_av_dbexTiC(1,1:end),'-.x');p5.MarkerSize = 10;
p5.MarkerIndices = 1:floor(Num_iter/8):length(iter);

legend('IC-GT','TiCoPD');
xlabel('Iteration number');
ylabel('MSD (dB)');

%






